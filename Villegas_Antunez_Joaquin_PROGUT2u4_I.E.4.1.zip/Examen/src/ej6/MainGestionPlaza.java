package ej6;

import java.io.IOException;

public class MainGestionPlaza {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Plaza p1=new Plaza(1, "coche 1", true, 0);
		
		p1.menu();
	}

}
