package ej5;

public class PruebaVehiculo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Coche c1=new Coche("0000BBB","gris plata",3);
		Moto m1=new Moto("2222BBB","negro",2);
		
		c1.imprimircoche();
		m1.imprimirmoto();
	}

}
