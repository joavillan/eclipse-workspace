package ej5;

public class Moto extends Vehiculo{

	private int numPlazas;
	
	@Override
	public void setNruedas(int nruedas) {
		// TODO Auto-generated method stub
		nruedas=2;
		super.setNruedas(nruedas);
	}
	
	
	Moto(String matricula, String color){
		
	}
	
	Moto(String matricula, String color, int cilindrada){
		
	}

	Moto(String matricula, String color, int cilindrada, int potencia){
		
	}
	
	Moto(String matricula, String color, int cilindrada, int potencia, int numPlazas){
		
	}
	
	void imprimirmoto() {
		System.out.println("Informaci�n de la moto");
		System.out.println("La matricula es: "+getMatricula());
		System.out.println("El color es: "+getColor());
		System.out.println("El n�mero de plazas es: "+ numPlazas);
	}
}
