package ej5;

public class Coche extends Vehiculo{
	
	private int numPuertas;

	@Override
	public void setNruedas(int nruedas) {
		// TODO Auto-generated method stub
		nruedas=4;
		super.setNruedas(nruedas);
	}
	
	Coche(String matricula, String color){
		
	}
	
	Coche(String matricula, String color, int cilindrada){
		
	}
	
	Coche(String matricula, String color, int cilindrada, int potencia){
		
	}
	
	Coche(String matricula, String color, int cilindrada, int potencia, int numPuertas){
		
	}
	
	void imprimircoche(){
		System.out.println("Informaci�n del coche");
		System.out.println("La matricula es: "+getMatricula());
		System.out.println("El color es: "+getColor());
		System.out.println("El n�mero de puertas es: "+numPuertas);
	}
}
