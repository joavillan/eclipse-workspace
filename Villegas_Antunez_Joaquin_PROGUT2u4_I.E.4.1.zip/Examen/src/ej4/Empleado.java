package ej4;

public class Empleado extends Direccion{

	String nombre;
	int salario;
	Direccion direccion;
	
	
	Empleado(String nombre, int salario, Direccion direccion){
	super();
	this.nombre=nombre;
	this.salario=salario;
	this.direccion=direccion;
	}


		void mostrar() {
		int a1=1;
		a1++;
		System.out.println("Empleado "+a1+":");
		System.out.println("Salario: "+salario);
		System.out.println("Direccion:"+ direccion);
		System.out.println("          Calle: "+calle);
		System.out.println("          N�mero: "+numero);
		System.out.println("          Puerta: "+piso);
		System.out.println("          Ciudad: "+ciudad);
	}

}
