package ej4;

public class Direccion {

	String calle;
	int numero;
	int piso;
	String ciudad;
	
	public Direccion() {
		// TODO Auto-generated constructor stub
	}
	
	Direccion(String calle, int numero, int piso, String ciudad){
		this.calle=calle;
		this.piso=piso;
		this.ciudad=ciudad;
	}
}
